let errorMessage = document.getElementById("error-message");

function validateForm() {
  let name = document.getElementById('name').value;
  let password = document.getElementById('password').value;
  let email = document.getElementById('email').value;
  let dateOfBirth = document.getElementById('dateofbirth').value;
  let terms = document.getElementById('terms').checked;

  if (!validateName(name)) {
    return false;
  } else if (!validatePassword(password)) {
    return false;
  } else if (!validateEmail(email)) {
    return false;
  } else if (!validateDateOfBirth(dateOfBirth)) {
    return false;
  } else if (!validateTerms(terms)) {
    return false;
  }

  errorMessage.innerHTML = "Everything's Correct";
  return true;
}

function validateName(name) {
  if (name.length < 5) {
    errorMessage.innerHTML = "Please use 5 characters or more for the name.";
    return false;
  }
  return true;
}

function validatePassword(password) {
  if (password.length < 6) {
    errorMessage.innerHTML = "Please use 6 characters or more for the password.";
    return false;
  }
  return true;
}

function validateEmail(email) {
  if (!email.includes('@') || !email.includes('.')) {
    errorMessage.innerHTML = "Please enter a valid email address.";
    return false;
  }
  return true;
}

function validateDateOfBirth(dateOfBirth) {
  if (dateOfBirth === "") {
    errorMessage.innerHTML = "Please enter your date of birth.";
    return false;
  }
  return true;
}

function validateTerms(terms) {
  if (!terms) {
    errorMessage.innerHTML = "Please accept the terms and conditions.";
    return false;
  }
  return true;
}